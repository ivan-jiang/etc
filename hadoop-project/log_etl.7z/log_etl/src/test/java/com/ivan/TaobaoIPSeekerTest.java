package com.ivan;

import org.junit.Test;

import com.ivan.offline.analysis.utils.ip.IPSeeker.RegionInfo;
import com.ivan.offline.analysis.utils.ip.TaobaoIPSeeker;

public class TaobaoIPSeekerTest {
	
	@Test
	public void test() {
		TaobaoIPSeeker ipSeeker = TaobaoIPSeeker.getInstance();
		RegionInfo ri = ipSeeker.seek("124.167.198.109");
		System.out.println(ri);
	}
}
