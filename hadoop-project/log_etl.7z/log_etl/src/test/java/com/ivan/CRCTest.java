package com.ivan;

import java.util.zip.CRC32;

import org.junit.Test;

public class CRCTest {
	
	@Test
	public void test() {
		CRC32 crc32 = new CRC32();
		crc32.reset();
		crc32.update("hello".getBytes());		
		System.out.println(crc32.getValue());
		
		crc32.update("world".getBytes());		
		System.out.println(crc32.getValue());
		
		crc32.update("hello".getBytes());		
		System.out.println(crc32.getValue());
	}
}
