package com.ivan.offline.analysis.mr;

import java.io.IOException;
import java.util.Date;
import java.util.Map;
import java.util.zip.CRC32;

import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ivan.offline.analysis.common.EventLogConstants;
import com.ivan.offline.analysis.common.EventLogConstants.EventEnum;
import com.ivan.offline.analysis.common.EventLogConstants.PlatformNameConstants;
import com.ivan.offline.analysis.utils.LogUtils;

/**
 * 解析日志数据，并把解析结果存入hbase
 * 
 * @author Ivan
 *
 */
public class LogDataETLMapper extends
		Mapper<LongWritable, Text, NullWritable, Put> {
	private static final Logger LOGGER = LoggerFactory
			.getLogger(LogDataETLMapper.class);
	private LogUtils logUtils;
	private CRC32 crc32 = new CRC32();
	private long currentDayMillis = 0;

	@Override
	protected void setup(
			Mapper<LongWritable, Text, NullWritable, Put>.Context context)
			throws IOException, InterruptedException {
		logUtils = new LogUtils();
		crc32 = new CRC32();
		currentDayMillis = new Date().getTime();
	}

	@Override
	protected void map(LongWritable key, Text value,
			Mapper<LongWritable, Text, NullWritable, Put>.Context context)
			throws IOException, InterruptedException {
		Map<String, String> clientInfo = logUtils.parseLog(value.toString());

		// 过滤无效数据
		if (clientInfo.isEmpty()) {
			LOGGER.debug("无效数据: " + value);
			return;
		}

		// 获取事件名称，按照不同事件进行处理
		String eventAliasName = clientInfo
				.get(EventLogConstants.LOG_COLUMN_NAME_EVENT_NAME);
		EventEnum event = EventEnum.valueOfAlias(eventAliasName);
		switch (event) {
		case CHARGEREFUND:
		case CHARGEREQUEST:
		case CHARGESUCCESS:
		case EVENT:
		case LAUNCH:
		case PAGEVIEW:
			this.handleData(clientInfo, event, context, value.toString());
			break;
		default:
			LOGGER.debug("无效事件: " + eventAliasName);
			break;
		}
	}

	/**
	 * 处理数据
	 * 
	 * @param clientInfo
	 * @param event
	 * @param context
	 * @param logStr
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private void handleData(Map<String, String> clientInfo, EventEnum event,
			Context context, String logStr) throws IOException,
			InterruptedException {
		String platform = clientInfo.get(EventLogConstants.LOG_COLUMN_NAME_PLATFORM);
		String uuid = clientInfo.get(EventLogConstants.LOG_COLUMN_NAME_UUID);
		String serverTime = clientInfo.get(EventLogConstants.LOG_COLUMN_NAME_SERVER_TIME);

		// 检查数据的完整性，不满足完整性的数据不需要处理
		if (!this.checkFieldIntegrity(event, platform, clientInfo)) {
			LOGGER.debug("数据不完整" + logStr);
			return;
		}

		// 去除无用数据
		clientInfo.remove(EventLogConstants.LOG_COLUMN_NAME_USER_AGENT);

		byte[] rowkey = this.generateRowKey(uuid, Long.valueOf(serverTime),
				clientInfo);
		// put对象创建
		Put put = new Put(rowkey);
		for (Map.Entry<String, String> entry : clientInfo.entrySet()) {
			if (StringUtils.isNotBlank(entry.getKey()) && StringUtils.isNotBlank(entry.getValue())) {
				put.add(EventLogConstants.BYTES_EVENT_LOGS_FAMILY_NAME,
						Bytes.toBytes(entry.getKey()),
						Bytes.toBytes(entry.getValue()));
			}
		}
		
		context.write(NullWritable.get(), put);
	}

	/**
	 * 构造rowkey，由uuid或clientInfo的crc值构成
	 * 
	 * @param uuid
	 * @param serverTime
	 * @param clientInfo
	 * @return
	 */
	private byte[] generateRowKey(String uuid, long serverTime,
			Map<String, String> clientInfo) {
		this.crc32.reset(); // 重置
		if (StringUtils.isNotBlank(uuid)) {
			this.crc32.update(uuid.getBytes());
		} 
			
		this.crc32.update(Bytes.toBytes(clientInfo.hashCode()));
		byte[] bf = Bytes.toBytes(this.crc32.getValue());

		return bf;
	}

	/**
	 * 检查数据的完整性，如果数据完整返回true，否则返回false
	 * 
	 * @param event
	 * @param platform
	 * @param clientInfo
	 * @return
	 */
	private boolean checkFieldIntegrity(EventEnum event, String platform,
			Map<String, String> clientInfo) {
		boolean result = StringUtils.isNotBlank(platform)
				&& event != null
				&& StringUtils.isNotBlank(clientInfo
						.get(EventLogConstants.LOG_COLUMN_NAME_SERVER_TIME));

		if (result) {
			// 针对具体的event进行字段信息的判断
			String uuid = clientInfo
					.get(EventLogConstants.LOG_COLUMN_NAME_UUID);
			String sessionId = clientInfo
					.get(EventLogConstants.LOG_COLUMN_NAME_SESSION_ID);
			String memberId = clientInfo
					.get(EventLogConstants.LOG_COLUMN_NAME_MEMBER_ID);
			String orderId = clientInfo
					.get(EventLogConstants.LOG_COLUMN_NAME_ORDER_ID);

			switch (platform) {
			case PlatformNameConstants.PC_WEBSITE_SDK:
				result = result && StringUtils.isNotBlank(uuid)
						&& StringUtils.isNotBlank(sessionId);
				// 处理不同event的
				switch (event) {
				case CHARGEREQUEST: // 订单产生事件
					result = result
							&& StringUtils.isNotBlank(orderId)
							&& StringUtils
									.isNotBlank(clientInfo
											.get(EventLogConstants.LOG_COLUMN_NAME_ORDER_CURRENCY_TYPE))
							&& StringUtils
									.isNotBlank(clientInfo
											.get(EventLogConstants.LOG_COLUMN_NAME_ORDER_PAYMENT_TYPE))
							&& StringUtils
									.isNotBlank(EventLogConstants.LOG_COLUMN_NAME_ORDER_CURRENCY_AMOUNT);
					break;
				case PAGEVIEW:
					result = result
							&& StringUtils
									.isNotBlank(clientInfo
											.get(EventLogConstants.LOG_COLUMN_NAME_CURRENT_URL));
					break;
				case LAUNCH:
					// 没有特殊要求
					break;
				case EVENT:
					result = result
							&& StringUtils
									.isNotBlank(EventLogConstants.LOG_COLUMN_NAME_EVENT_CATEGORY)
							&& StringUtils
									.isNotBlank(EventLogConstants.LOG_COLUMN_NAME_EVENT_ACTION);
					break;
				default:
					// 不应该出现其他事件类型
					result = false;
					break;
				}
				break;
			case PlatformNameConstants.JAVA_SERVER_SDK:
				result = result && StringUtils.isNotBlank(memberId);
				switch (event) {
				case CHARGESUCCESS:
				case CHARGEREFUND:
					result = result && StringUtils.isNotBlank(orderId);
					break;
				default:
					// 不应该出现此event
					result = false;
					break;
				}
				break;
			default:
				// 不应该出现的平台
				result = false;
				break;
			}
		}
		return result;
	}
}