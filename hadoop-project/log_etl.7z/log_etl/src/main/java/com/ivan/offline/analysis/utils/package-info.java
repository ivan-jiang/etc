/**
 * 
 */
/**
 * @author Ivan
 *
 */
package com.ivan.offline.analysis.utils;