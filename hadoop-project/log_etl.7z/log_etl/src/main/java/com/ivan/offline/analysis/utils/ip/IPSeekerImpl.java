package com.ivan.offline.analysis.utils.ip;

import org.apache.commons.collections.map.LRUMap;
import org.apache.log4j.Logger;

import com.ivan.offline.analysis.common.GlobalConstants;

/***
 * IP查找类，集成QQwry和taobao ip，提供LRC缓存以减少ip转换，提高性能
 * @author Ivan
 *
 */
public class IPSeekerImpl implements IPSeeker {
	private static final Logger LOGGER = Logger.getLogger(IPSeekerImpl.class);
	
	/**
	 * 本地纯真ip库查询
	 */
	private IPSeeker wryIPSeeker = QQwryIPSeeker.getInstance();
	
	/**
	 * 淘宝ip查询
	 */
	private IPSeeker tbIPSeeker = TaobaoIPSeeker.getInstance();
	
	// LRC缓存，减少ip地址转换。容量越大命中率越高，对服务器的内存要求也越高
	// TODO: 让缓存容量可配置
	private LRUMap foundIpMap = new LRUMap(1000);
	
	@Override
	public RegionInfo seek(String ip) {
		// LRC缓存有这个ip, 直接返回
		if (foundIpMap.containsKey(ip)) {
			return (RegionInfo)foundIpMap.get(ip);
		}
		
		RegionInfo info = wryIPSeeker.seek(ip);
		
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("ip查询:" + ip + ": " + info);
		}
		// 国家/省/城市，都为空时，就请求taobao ip查询
		if (info.getCountry().equals(GlobalConstants.DEFAULT_VALUE) &&
			info.getProvince().endsWith(GlobalConstants.DEFAULT_VALUE) &&
			info.getCity().equals(GlobalConstants.DEFAULT_VALUE)) {
			LOGGER.debug("淘宝ip查询");

			info = tbIPSeeker.seek(ip);
		}
		
		foundIpMap.put(ip, info);
		return info;
	}
}