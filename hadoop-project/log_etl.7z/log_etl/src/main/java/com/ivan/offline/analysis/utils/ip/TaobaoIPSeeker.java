package com.ivan.offline.analysis.utils.ip;

import java.io.IOException;
import java.net.URI;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ivan.offline.analysis.common.GlobalConstants;

/**
 * 淘宝ip查询的实现
 * @author Ivan
 *
 */
public class TaobaoIPSeeker implements IPSeeker {
	private static final Logger LOGGER = LoggerFactory.getLogger(TaobaoIPSeeker.class);
	private DefaultHttpClient client = null;
	private HttpGet request = null;

	private static TaobaoIPSeeker instance = null;
	
	static {
		instance = new TaobaoIPSeeker();
	}
	
	public static TaobaoIPSeeker getInstance() {
		return instance;
	}
	
	private TaobaoIPSeeker() {
		client = new DefaultHttpClient();
		request = new HttpGet();
	}
	
	@Override
	public RegionInfo seek(String ip) {
		RegionInfo info = new RegionInfo();
		request.setURI(URI.create(GlobalConstants.TAOBAO_IP_SEEKER_ADDR + "?ip=" + ip));
		try {
			HttpResponse response = client.execute(request);
			// http请求成功，状态码200表示操作成功
			if (response.getStatusLine().getStatusCode() == 200) {
				String json = EntityUtils.toString(response.getEntity());
				
				JSONObject jo = new JSONObject(json);
				if (jo.getInt("code") == 0) {	// 成功
					JSONObject dataJO = jo.getJSONObject("data");
				//	System.out.println(dataJO.getString("country") + "," + dataJO.getString("region") + "," + dataJO.getString("city"));
					
					info.setCountry(dataJO.getString("country"));
					info.setProvince(dataJO.getString("region"));
					info.setCity(dataJO.getString("city"));						
				}
			} else {
				// http请求成功，但是状态码表示操作失败
				LOGGER.error(response.getStatusLine().toString());
			}
		} catch (IOException e) {
			e.printStackTrace();
			
			LOGGER.error("查找ip出错: " + ip);
			
			// 淘宝ip查询有限制10qps, 即每秒钟只能查询10次,每次查询间隔100ms, 如果查询出错，休息一半的间隔时间，即50ms
			try {
				Thread.sleep(50);
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
		}
		
		return info;
	}
}
