package com.ivan.offline.analysis.utils.ip;

import com.ivan.offline.analysis.common.GlobalConstants;

public interface IPSeeker {
	
	public RegionInfo seek(String ip);
	
	/**
     * 地域描述信息内部类
     * 
     * @author ibf
     *
     */
    public static class RegionInfo {
        private String country = GlobalConstants.DEFAULT_VALUE;
        private String province = GlobalConstants.DEFAULT_VALUE;
        private String city = GlobalConstants.DEFAULT_VALUE;

        public String getCountry() {
            return country;
        }

        public void setCountry(String country) {
            this.country = country;
        }

        public String getProvince() {
            return province;
        }

        public void setProvince(String province) {
            this.province = province;
        }

        public String getCity() {
            return city;
        }

        public void setCity(String city) {
            this.city = city;
        }

        @Override
        public String toString() {
            return "RegionInfo [country=" + country + ", province=" + province + ", city=" + city
                    + "]";
        }
    }
}
