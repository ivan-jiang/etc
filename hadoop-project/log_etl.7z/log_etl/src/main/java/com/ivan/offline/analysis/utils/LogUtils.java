package com.ivan.offline.analysis.utils;

import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ivan.offline.analysis.common.EventLogConstants;
import com.ivan.offline.analysis.utils.ip.IPSeeker.RegionInfo;
import com.ivan.offline.analysis.utils.ip.IPSeekerImpl;

import cz.mallat.uasparser.UserAgentInfo;

public class LogUtils {
	private static final Logger LOGGER = LoggerFactory.getLogger(LogUtils.class);
	private static final IPSeekerImpl ipSeeker = new IPSeekerImpl();
	
	public Map<String, String> parseLog(String log) {
		Map<String, String> clientInfo = new HashMap<String, String>();
        if (StringUtils.isNotBlank(log)) {
            String[] splits = log.trim().split(EventLogConstants.LOG_SEPARTIOR);
            if (splits.length == 3) {
                // 数据格式正确，可以分割
                // IP地址
                clientInfo.put(EventLogConstants.LOG_COLUMN_NAME_IP, splits[0].trim());
                // 服务器时间
                long nginxTime = TimeUtil.parseNginxServerTime2Long(splits[1].trim());
                if (nginxTime != -1) {
                    clientInfo.put(EventLogConstants.LOG_COLUMN_NAME_SERVER_TIME,
                            String.valueOf(nginxTime));
                }
                // 处理请求参数
                String requestStr = splits[2];
                int index = requestStr.indexOf("?");
                if (index > -1) {
                    String requestBody = requestStr.substring(index + 1);
                    
                    // 解析请求内容
                    handleRequestBody(clientInfo, requestBody);
                    // 添加IP解析功能
                    RegionInfo info = ipSeeker.seek(clientInfo.get(EventLogConstants.LOG_COLUMN_NAME_IP));
                    clientInfo.put(EventLogConstants.LOG_COLUMN_NAME_CITY, info.getCity());
                    clientInfo.put(EventLogConstants.LOG_COLUMN_NAME_PROVINCE, info.getProvince());
                    clientInfo.put(EventLogConstants.LOG_COLUMN_NAME_COUNTRY, info.getCountry());

                    UserAgentInfo userAgentInfo = UserAgentUtil.parse(clientInfo.get(EventLogConstants.LOG_COLUMN_NAME_USER_AGENT));
                    if (userAgentInfo != null) {
                        clientInfo.put(EventLogConstants.LOG_COLUMN_NAME_BROWSER_NAME, userAgentInfo.getUaFamily());
                        clientInfo.put(EventLogConstants.LOG_COLUMN_NAME_BROWSER_VERSION, userAgentInfo.getBrowserVersionInfo());
                        clientInfo.put(EventLogConstants.LOG_COLUMN_NAME_OS_NAME, userAgentInfo.getOsFamily());
                        clientInfo.put(EventLogConstants.LOG_COLUMN_NAME_OS_VERSION, userAgentInfo.getOsName());
                    }
                } else {
                    // 没有请求参数
                    clientInfo.clear();
                }
            }
        }
        return clientInfo;
	}
	
	/**
     * 解析请求内容
     * ver=1&en=e_l&pl=website&sdk=js： 以‘&’为分隔符，‘=’为key和value的划分
     * 
     * @param clientInfo
     * @param requestBody
     */
    private static void handleRequestBody(Map<String, String> clientInfo, String requestBody) {
        String[] requestParames = requestBody.split("&");
        for (String parame : requestParames) {
            if (StringUtils.isNotBlank(parame)) {
                int index = parame.indexOf("=");
                if (index < 0) {
                    LOGGER.debug("请求数据格式错误，格式必须为key=value" + parame);
                    continue;
                }

                String key, value = null;
                try {
                    key = parame.substring(0, index);
                    value = URLDecoder.decode(parame.substring(index + 1), "utf-8");
                } catch (Exception e) {
                    LOGGER.debug("解析参数出错", e);
                    continue;
                }

                if (StringUtils.isNotBlank(key) && StringUtils.isNotBlank(value)) {
                    clientInfo.put(key, value);
                }
            }
        }
    }
}
